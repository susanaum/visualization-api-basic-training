/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else {
		var a = factory();
		for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];
	}
})(self, function() {
return /******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/SampleBarChartEditorModel.js":
/*!******************************************!*\
  !*** ./src/SampleBarChartEditorModel.js ***!
  \******************************************/
/***/ (() => {

eval("if (!mstrmojo.plugins.SampleBarChart) {\n  mstrmojo.plugins.SampleBarChart = {};\n}\n\nmstrmojo.requiresCls(\"mstrmojo.vi.models.editors.CustomVisEditorModel\");\nvar $WT = mstrmojo.vi.models.editors.CustomVisEditorModel.WIDGET_TYPE;\nmstrmojo.plugins.SampleBarChart.SampleBarChartEditorModel = mstrmojo.declare(mstrmojo.vi.models.editors.CustomVisEditorModel, null, {\n  scriptClass: \"mstrmojo.plugins.SampleBarChart.SampleBarChartEditorModel\",\n  cssClass: \"samplebarchart-editor-model\",\n  getCustomProperty: function getCustomProperty() {\n    return [{\n      name: \"Demo Custom Vis\",\n      value: []\n    }];\n  }\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvU2FtcGxlQmFyQ2hhcnRFZGl0b3JNb2RlbC5qcy5qcyIsIm5hbWVzIjpbIm1zdHJtb2pvIiwicGx1Z2lucyIsIlNhbXBsZUJhckNoYXJ0IiwicmVxdWlyZXNDbHMiLCIkV1QiLCJ2aSIsIm1vZGVscyIsImVkaXRvcnMiLCJDdXN0b21WaXNFZGl0b3JNb2RlbCIsIldJREdFVF9UWVBFIiwiU2FtcGxlQmFyQ2hhcnRFZGl0b3JNb2RlbCIsImRlY2xhcmUiLCJzY3JpcHRDbGFzcyIsImNzc0NsYXNzIiwiZ2V0Q3VzdG9tUHJvcGVydHkiLCJuYW1lIiwidmFsdWUiXSwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsid2VicGFjazovL3NhbXBsZWJhcmNoYXJ0Ly4vc3JjL1NhbXBsZUJhckNoYXJ0RWRpdG9yTW9kZWwuanM/YmM2MyJdLCJzb3VyY2VzQ29udGVudCI6WyJpZiAoIW1zdHJtb2pvLnBsdWdpbnMuU2FtcGxlQmFyQ2hhcnQpIHsgbXN0cm1vam8ucGx1Z2lucy5TYW1wbGVCYXJDaGFydCA9IHt9OyB9XG5tc3RybW9qby5yZXF1aXJlc0NscyhcIm1zdHJtb2pvLnZpLm1vZGVscy5lZGl0b3JzLkN1c3RvbVZpc0VkaXRvck1vZGVsXCIpO1xuXG5jb25zdCB7IFdJREdFVF9UWVBFOiAkV1QgfSA9IG1zdHJtb2pvLnZpLm1vZGVscy5lZGl0b3JzLkN1c3RvbVZpc0VkaXRvck1vZGVsO1xuXG5tc3RybW9qby5wbHVnaW5zLlNhbXBsZUJhckNoYXJ0LlNhbXBsZUJhckNoYXJ0RWRpdG9yTW9kZWwgPSBtc3RybW9qby5kZWNsYXJlKFxuICBtc3RybW9qby52aS5tb2RlbHMuZWRpdG9ycy5DdXN0b21WaXNFZGl0b3JNb2RlbCxcbiAgbnVsbCxcbiAge1xuICAgIHNjcmlwdENsYXNzOiBcIm1zdHJtb2pvLnBsdWdpbnMuU2FtcGxlQmFyQ2hhcnQuU2FtcGxlQmFyQ2hhcnRFZGl0b3JNb2RlbFwiLFxuICAgIGNzc0NsYXNzOiBcInNhbXBsZWJhcmNoYXJ0LWVkaXRvci1tb2RlbFwiLFxuICAgIGdldEN1c3RvbVByb3BlcnR5KCkge1xuICAgICAgcmV0dXJuIFtcbiAgICAgICAge1xuICAgICAgICAgIG5hbWU6IFwiRGVtbyBDdXN0b20gVmlzXCIsXG4gICAgICAgICAgdmFsdWU6IFtdLFxuICAgICAgICB9LFxuICAgICAgXTtcbiAgICB9LFxuICB9XG4pO1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxJQUFJLENBQUNBLFFBQVEsQ0FBQ0MsT0FBVCxDQUFpQkMsY0FBdEIsRUFBc0M7RUFBRUYsUUFBUSxDQUFDQyxPQUFULENBQWlCQyxjQUFqQixHQUFrQyxFQUFsQztBQUF1Qzs7QUFDL0VGLFFBQVEsQ0FBQ0csV0FBVCxDQUFxQixpREFBckI7QUFFQSxJQUFxQkMsR0FBckIsR0FBNkJKLFFBQVEsQ0FBQ0ssRUFBVCxDQUFZQyxNQUFaLENBQW1CQyxPQUFuQixDQUEyQkMsb0JBQXhELENBQVFDLFdBQVI7QUFFQVQsUUFBUSxDQUFDQyxPQUFULENBQWlCQyxjQUFqQixDQUFnQ1EseUJBQWhDLEdBQTREVixRQUFRLENBQUNXLE9BQVQsQ0FDMURYLFFBQVEsQ0FBQ0ssRUFBVCxDQUFZQyxNQUFaLENBQW1CQyxPQUFuQixDQUEyQkMsb0JBRCtCLEVBRTFELElBRjBELEVBRzFEO0VBQ0VJLFdBQVcsRUFBRSwyREFEZjtFQUVFQyxRQUFRLEVBQUUsNkJBRlo7RUFHRUMsaUJBSEYsK0JBR3NCO0lBQ2xCLE9BQU8sQ0FDTDtNQUNFQyxJQUFJLEVBQUUsaUJBRFI7TUFFRUMsS0FBSyxFQUFFO0lBRlQsQ0FESyxDQUFQO0VBTUQ7QUFWSCxDQUgwRCxDQUE1RCJ9\n//# sourceURL=webpack-internal:///./src/SampleBarChartEditorModel.js\n");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/SampleBarChartEditorModel.js"]();
/******/ 	
/******/ 	return __webpack_exports__;
/******/ })()
;
});